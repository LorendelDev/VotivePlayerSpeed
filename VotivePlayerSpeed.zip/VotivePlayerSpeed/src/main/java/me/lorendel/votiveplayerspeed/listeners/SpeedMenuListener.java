package me.lorendel.votiveplayerspeed.listeners;

import me.lorendel.votiveplayerspeed.VotivePlayerSpeed;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;

public class SpeedMenuListener implements Listener {

    Plugin plugin = VotivePlayerSpeed.getPlugin(VotivePlayerSpeed.class);

    @EventHandler
    public void onSpeedMenuClick(InventoryClickEvent e){

        if(e.getView().getTitle().equalsIgnoreCase("Speed Menu"))

        if(e.getCurrentItem() == null){
            return;
        }

        if(e.getCurrentItem().getType() == Material.REDSTONE){

            Double walkingSpeed = plugin.getConfig().getDouble("WalkingSpeed");
            if(walkingSpeed == 0.0){
                plugin.getConfig().set("WalkingSpeed", 0.05);
                e.getCurrentItem().setAmount(2);
            }else if(walkingSpeed == 0.05) {
                plugin.getConfig().set("WalkingSpeed", 0.1);
                e.getCurrentItem().setAmount(3);
            }else if(walkingSpeed == 0.1){
                plugin.getConfig().set("WalkingSpeed", 0.15);
                e.getCurrentItem().setAmount(4);
            }else if(walkingSpeed == 0.15){
                plugin.getConfig().set("WalkingSpeed", 0.2);
                e.getCurrentItem().setAmount(5);
            }else if(walkingSpeed == 0.2){
                plugin.getConfig().set("WalkingSpeed", 0.0);
                e.getCurrentItem().setAmount(1);
            }

            ArrayList<String> lore = new ArrayList<>();
            lore.add(ChatColor.YELLOW + "Current speed: " + plugin.getConfig().getDouble("WalkingSpeed"));
            ItemMeta itemMeta = e.getCurrentItem().getItemMeta();
            itemMeta.setLore(lore);
            e.getCurrentItem().setItemMeta(itemMeta);

            e.setCancelled(true);


        }

    }

}
