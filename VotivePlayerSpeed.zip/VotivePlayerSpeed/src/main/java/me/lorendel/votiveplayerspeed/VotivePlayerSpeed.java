package me.lorendel.votiveplayerspeed;

import me.lorendel.votiveplayerspeed.commands.*;
import me.lorendel.votiveplayerspeed.listeners.SpeedMenuListener;
import org.bukkit.plugin.java.JavaPlugin;

public final class VotivePlayerSpeed extends JavaPlugin {

    @Override
    public void onEnable() {

        getCommand("walk").setExecutor(new WalkCommand());
        getCommand("normalSpeed").setExecutor(new NormalSpeedCommand());
        getCommand("speedmenu").setExecutor(new SpeedMenuCommand());

        getServer().getPluginManager().registerEvents(new SpeedMenuListener(), this);
        System.out.println("VotivePlayerSpeed включён!");

        getConfig().options().copyDefaults();
        saveDefaultConfig();

    }


}
